import 'package:flutter/material.dart';

const PRIMARY_COLOR = Color(0xFF1565C0);
const SECONDARY_COLOR = Color(0xFF90CAF9);
const BACKGROUND_COLOR = Color(0xFFF5F5F5);
const TEXT_COLOR = Color(0xFF212121);
const ERROR_COLOR = Color(0xFFD32F2F);
